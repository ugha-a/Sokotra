<?php

namespace App\Http\Middleware;

use App\Models\ContentPage;
use App\Support\Settings;
use Illuminate\Http\Request;
use Inertia\Middleware;

class HandleInertiaRequests extends Middleware
{
    /**
     * The root template that's loaded on the first page visit.
     *
     * @see https://inertiajs.com/server-side-setup#root-template
     *
     * @var string
     */
    protected $rootView = 'app';

    /**
     * Determines the current asset version.
     *
     * @see https://inertiajs.com/asset-versioning
     */
    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    /**
     * Define the props that are shared by default.
     *
     * @see https://inertiajs.com/shared-data
     *
     * @return array<string, mixed>
     */
    public function share(Request $request): array
    {
        return [
            ...parent::share($request),
            'name' => config('app.name'),
            'auth' => [
                'user' => $request->user(),
                'roles' => $request->user()?->getRoleNames()->values()->all() ?? [],
            ],
            'notifications' => fn () => $request->user()
                ? ['unread' => $request->user()->unreadNotifications()->count()]
                : null,
            'riskDisclaimer' => fn () => Settings::get('content.risk_disclaimer'),
            'legalPages' => fn () => ContentPage::query()->where('is_published', true)->orderBy('title')->get(['slug', 'title'])
                ->map(fn (ContentPage $page) => ['slug' => $page->slug, 'title' => $page->title])->values()->all(),
            'sidebarOpen' => ! $request->hasCookie('sidebar_state') || $request->cookie('sidebar_state') === 'true',
        ];
    }
}
